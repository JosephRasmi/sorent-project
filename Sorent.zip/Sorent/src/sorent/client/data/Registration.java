/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorent.client.data;

import sorent.client.HttpsClientPost;

/**
 *
 * @author xerxesj
 */
public final class Registration extends HttpsClientPost{
    
    private String fname;
    private String lname;
    private String phone;
    private String nationalId;
    private String emailAddress;
    private String physicalAddress;
    private String password;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Registration() {
        // Initialize data sent
        data = "";
        this.setFname(DEFAULT_STRING);
        this.setLname(DEFAULT_STRING);
        this.setPhone(DEFAULT_STRING);
        this.setNationalId(DEFAULT_STRING);
        this.setEmailAddress(DEFAULT_STRING);
        this.setPhysicalAddress(DEFAULT_STRING);
        this.setPassword(DEFAULT_STRING);
        
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        this.fname = fname;
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        this.lname = lname;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getNationalId() {
        return nationalId;
    }

    public void setNationalId(String nationalId) {
        this.nationalId = nationalId;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getPhysicalAddress() {
        return physicalAddress;
    }

    public void setPhysicalAddress(String physicalAddress) {
        this.physicalAddress = physicalAddress;
    }
   
    @Override
    public String postString() {
       
        data = FNAME + EQUALS + this.fname + PAIRER +
               LNAME + EQUALS + this.lname + PAIRER +
               PHONE + EQUALS + this.phone + PAIRER +
               NATIONAL_ID + EQUALS + this.nationalId + PAIRER +
               EMAIL + EQUALS + this.emailAddress + PAIRER +
               PYSICAL_ADDRESS + EQUALS + this.physicalAddress;
       
       return super.postString();
    }
}
