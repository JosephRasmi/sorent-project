/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorent.client.data;

import sorent.client.HttpsClientPost;

/**
 *
 * @author xerxesj
 */
public final class Login extends HttpsClientPost {

     //public final static int EMAIL_USED = 0;
    //public final static int PHONE_USED = 1;
    //public final static int NATIONAL_ID_USED = 2;
    
    private String userId;
    private String password;
    //private int idUsed;
    
    public Login() {
        
        //this.idUsed = idUsed;
        data = "";
        setUserId(DEFAULT_STRING);
        setPassword(DEFAULT_STRING);
    }

    public void setUserId(String userId) {
       this.userId = userId;
        
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getUserId() {
        return userId;
    }

    public String getPassword() {
        return password;
    }
    
     @Override
    public String postString() {
        
        data = PHONE + EQUALS + this.userId + PAIRER +
                PASSWORD + EQUALS + this.password;
                
        
        return super.postString();
    }

   
    
}
