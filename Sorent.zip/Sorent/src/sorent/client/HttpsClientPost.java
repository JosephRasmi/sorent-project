/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorent.client;

import java.net.*;
import java.io.*;
import java.util.Scanner;

/**
 *
 * @author xerxesj
 */
public class HttpsClientPost implements ClientPost {
    
    public static String MALFORMED_URL = "MALFORMED_URL";
    public static String CONNECTION_ERROR = "ERROR IN CONNECTING";
    
    protected final String DEFAULT_STRING = "UNKNOWN";
     
    private final String DEFAULT_URL = "http://localhost/mine/";
    
    protected String url_file;
    protected String data;
    
    private URL url;
    private HttpURLConnection conn;
    

    public HttpsClientPost() {
        
        url_file = DEFAULT_URL;
    }
   
    @Override
    public String postString() {
       
        url_file += "?" + data; // TEMPORARY USED FOR TESTING.
       
        String result = "";
       StringBuilder stringBuilder = new StringBuilder();
       
       try {
           
           url = new URL(url_file);
           
           conn = (HttpURLConnection) url.openConnection();
           
           conn.setDoOutput(true);
           conn.setRequestMethod("POST");
           conn.connect();
           
           try (DataOutputStream outStream = new DataOutputStream(conn.getOutputStream())) {
               outStream.writeBytes(data);
               outStream.flush();
           }
           
           Scanner scan = new Scanner(conn.getInputStream());
           
           while(scan.hasNextLine()){
               stringBuilder.append(scan.nextLine());
           }
            
           // data correctly read
           result = stringBuilder.toString();
           conn.disconnect();
           
       } catch (MalformedURLException ex) {
           
           result = MALFORMED_URL;
        
       } catch (IOException ex) {
            
           result = CONNECTION_ERROR;
           conn.disconnect();
        }
       
       
       return result;
    }
    
}
