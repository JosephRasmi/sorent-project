/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorent.client;

import javax.swing.JPanel;
import sorent.client.windows.*;

/**
 *
 * @author xerxesj
 * parent for login and registration forms
 */
public class RegLogin extends JPanel{
    
    private RegistrationWindow register;
    private LoginWindow login;

    public RegLogin() {
        
        register = new RegistrationWindow();
        login = new LoginWindow();
        this.add(login);
        this.add(register);
        register.setVisible(false);
        
    }
    
   
    public void setRegister(){
        
            login.setVisible(false);
            register.setVisible(true);
       
    }
    
    public void setLogin(){
        login.setVisible(true);
        register.setVisible(false);
    }
    
    
}
