/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorent.client;

import sorent.PostData;
/**
 *
 * @author xerxesj
 */
public interface ClientPost extends PostData {

    final String LOANAMT = "amt";
    final String DATEDUE = "due_date";
    
}
