/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorent;

import java.awt.Dimension;
import java.io.UnsupportedEncodingException;
import javax.swing.JFrame;
import sorent.client.RegLogin;

/**
 *
 * @author xerxesj
 */
public class Sorent {

    /**
     * @param args the command line arguments
     * @throws java.io.UnsupportedEncodingException
     */
    public static void main(String[] args) throws UnsupportedEncodingException {
        RegLogin myLogin = new RegLogin();
        JFrame frame = new JFrame();
        frame.setMinimumSize(new Dimension(850,600));
        frame.setLocation(200, 30);
        frame.getContentPane().add(myLogin);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
}
