/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sorent;

/**
 *
 * @author xerxesj
 */
public interface PostData {
    
   final String FNAME = "fname";
   final String LNAME = "lname";
   final String NATIONAL_ID = "id";
   final String AMOUNT = "amt";
   final String PASSWORD = "password";
   final String EMAIL = "emailAddress";
   final String PHONE = "phone_no";
   final String ACCOUNT = "account_no";
   final String PAIRER = "&";
   final String EQUALS = "=";
   final String PYSICAL_ADDRESS = "physicalAddress";
   
   String postString ();
    
}
